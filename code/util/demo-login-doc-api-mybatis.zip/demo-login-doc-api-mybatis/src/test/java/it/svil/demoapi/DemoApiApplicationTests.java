package it.svil.demoapi;

import com.fasterxml.jackson.databind.ObjectMapper;
import it.svil.demoapi.security.controller.AuthController;

import it.svil.demoapi.security.model.RegisterRequestDto;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@AutoConfigureMockMvc
class DemoApiApplicationTests {

    private AuthController userController;
    private MockMvc mockMvc;

    @Autowired
    public DemoApiApplicationTests(AuthController userController, MockMvc mockMvc) {
        this.userController = userController;
        this.mockMvc = mockMvc;
    }

    //@Test
    public void contextLoads() {
        assertThat(userController).isNotNull();
    }
    //@Test
    public void registerNewUser() throws Exception {
        RegisterRequestDto userRequestDto = new RegisterRequestDto();
        long millis = System.currentTimeMillis();
        userRequestDto.setEmail(millis + "@mail.it");
        userRequestDto.setFirstName("utente"+millis);
        userRequestDto.setPassword("111111");

        mockMvc.perform( MockMvcRequestBuilders
                        .post("/api/v1/auth/register")
                        .content(asJsonString(userRequestDto))
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.token").exists());
    }

    //@Test
    public void loginUserCorrect() throws Exception {
        RegisterRequestDto userRequestDto = new RegisterRequestDto();
        userRequestDto.setEmail("1695806889156@mail.it");
        userRequestDto.setPassword("111111");

        mockMvc.perform( MockMvcRequestBuilders
                        .post("/api/v1/auth")
                        .content(asJsonString(userRequestDto))
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.data.token").exists());
    }

    //@Test
    public void loginUserWrong() throws Exception {
        RegisterRequestDto userRequestDto = new RegisterRequestDto();
        userRequestDto.setEmail("mic.sav");
        userRequestDto.setPassword("34222");

        mockMvc.perform( MockMvcRequestBuilders
                        .post("/api/v1/auth")
                        .content(asJsonString(userRequestDto))
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest());
    }

    public static String asJsonString(final Object obj) {
        try {
            return new ObjectMapper().writeValueAsString(obj);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
