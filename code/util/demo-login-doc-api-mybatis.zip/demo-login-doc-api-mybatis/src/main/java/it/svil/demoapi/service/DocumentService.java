package it.svil.demoapi.service;

import it.svil.demoapi.dto.DocumentRequestDto;
import it.svil.demoapi.dto.DocumentResponseDto;
import it.svil.demoapi.mapper.DocumentMapper;
import it.svil.demoapi.model.Document;
import it.svil.demoapi.model.Type;
import it.svil.demoapi.security.service.AuthService;
import it.svil.demoapi.util.ConvertDocument;
import it.svil.demoapi.util.EnumUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service
public class DocumentService {
    private static final Logger log = LoggerFactory.getLogger(DocumentService.class);

    @Autowired
    private DocumentMapper documentMapper;
    @Autowired
    private AuthService authService;



    public Document add(DocumentRequestDto requestDto)  {
        Document document = new Document();
        if(requestDto != null){
            if (
                    requestDto.getName() != null && !requestDto.getName().isBlank()
                    && requestDto.getDocumentType() != null && EnumUtil.isValidDocType(requestDto.getDocumentType())
            ) {
                document.setName(requestDto.getName());
                document.setDocumentType(Type.valueOf(requestDto.getDocumentType()));

                String currentUser = authService.currentUserName();
                if(currentUser == null) {
                    log.error("current user is null");
                    document.setId(-1L);
                    return document;
                }
                document.setCreator(currentUser);
                document.setCreationDate(new Date());

                documentMapper.insert(document);
            }
        }
        document.setId(-1L);
        return document;
    }

    public Document getById(Long id){
        return documentMapper.findById(id);
    }

    public List<Document> getAll(){
        return documentMapper.findAll();
    }
    public Document update(Long id, DocumentRequestDto requestDto){
        Document document = this.getById(id);
        if(document.getId() != -1L) {
            if (requestDto.getName() != null && !requestDto.getName().isBlank())
                document.setName(requestDto.getName());
            if (requestDto.getDocumentType() != null && EnumUtil.isValidDocType(requestDto.getDocumentType()))
                document.setDocumentType(Type.valueOf(requestDto.getDocumentType()));

            documentMapper.update(document);
        }
        return document;
    }

    public boolean delete(Long id){
        Document document = this.getById(id);
        if(document != null && document.getId() != -1L) {
            documentMapper.delete(id);
            return true;
        }
        return false;
    }

    public DocumentResponseDto response(Document document){
        if(document == null || document.getId()== -1L) {
            DocumentResponseDto documentResponseDto = new DocumentResponseDto();
            documentResponseDto.setId(-1L);
            return documentResponseDto;
        }
        return ConvertDocument.convertDocument(document);
    }
}
