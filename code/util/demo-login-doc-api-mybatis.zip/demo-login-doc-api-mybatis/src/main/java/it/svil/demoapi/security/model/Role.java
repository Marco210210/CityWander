package it.svil.demoapi.security.model;

public enum Role {
  USER, ADMIN 
}
