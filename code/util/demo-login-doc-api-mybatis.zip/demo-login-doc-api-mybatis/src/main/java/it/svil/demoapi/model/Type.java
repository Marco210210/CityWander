package it.svil.demoapi.model;

 public enum Type   {PRINCIPAL, ATTACHMENT};

