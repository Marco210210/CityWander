package it.svil.demoapi.util;

import it.svil.demoapi.dto.DocumentResponseDto;
import it.svil.demoapi.model.Document;

public class ConvertDocument {
    public static DocumentResponseDto convertDocument(Document document){
        DocumentResponseDto responseDto = new DocumentResponseDto();
        responseDto.setId(document.getId());
        responseDto.setName(document.getName());
        responseDto.setDocumentType(document.getDocumentType().name());
        responseDto.setCreationDate(document.getCreationDate());
        responseDto.setCreator(document.getCreator());
        return responseDto;
    }
}