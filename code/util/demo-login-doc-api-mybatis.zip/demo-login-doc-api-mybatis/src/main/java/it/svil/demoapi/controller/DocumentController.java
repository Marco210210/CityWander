package it.svil.demoapi.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import it.svil.demoapi.dto.DocumentRequestDto;
import it.svil.demoapi.dto.DocumentResponseDto;
import it.svil.demoapi.dto.ResultDto;
import it.svil.demoapi.service.DocumentService;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping(value = "api/v1/document")
@Tag(name = "Document", description = "CRUD operations on documents")
public class DocumentController {
    private static final Logger log = LoggerFactory.getLogger(DocumentController.class);

    @Autowired
    private DocumentService documentService;

    @GetMapping(value = "/getDocumentById")
    @Operation(description = "Get document by id")
    public ResponseEntity<ResultDto<DocumentResponseDto>> getDocumentById(@RequestParam(name = "id") Long id){
        log.debug("call getDocumentById: " + id);
        ResultDto<DocumentResponseDto> result = new ResultDto<DocumentResponseDto>();

        try{
            DocumentResponseDto responseDto = documentService.response(documentService.getById(id));
            if(responseDto!=null){
                if(responseDto.getId().equals(-1L)){
                    result.setSuccessFalseResponse("Document with id " + id + " not exist");
                    result.setCode(HttpStatus.BAD_REQUEST.value());
                }else {
                    result.setSuccessTrueResponse("");
                    result.setData(responseDto);
                }
            }else{
                result.setSuccessFalseResponse("Bad request");
                result.setCode(HttpStatus.BAD_REQUEST.value());
            }
        }catch (Exception ex){
            log.error("error getDocumentById:", ex);

            result.setFailureResponse("Server error", HttpStatus.INTERNAL_SERVER_ERROR.value());
            return new ResponseEntity<>(result, HttpStatus.INTERNAL_SERVER_ERROR);
        }

        return new ResponseEntity<>(result, HttpStatus.OK);
    }

    @PutMapping(value = "/addDocument")
    @Operation(description = "Add new document")
    public ResponseEntity<ResultDto<DocumentResponseDto>> addDocument(@RequestBody DocumentRequestDto requestDto){
        log.debug("call addDocument");
        ResultDto<DocumentResponseDto> result = new ResultDto<DocumentResponseDto>();

        try{
            DocumentResponseDto responseDto = documentService.response(documentService.add(requestDto));
            if(responseDto!=null){
                if(responseDto.getId().equals(-1L)){
                    result.setSuccessFalseResponse("Document not created");
                    result.setCode(HttpStatus.BAD_REQUEST.value());
                }else {
                    result.setSuccessTrueResponse("Document created");
                    result.setData(responseDto);
                }
            }else{
                result.setSuccessFalseResponse("Bad request");
                result.setCode(HttpStatus.BAD_REQUEST.value());
            }

        }catch (Exception ex){
            log.error("error addDocument:", ex);

            result.setFailureResponse("Server error", HttpStatus.INTERNAL_SERVER_ERROR.value());
            return new ResponseEntity<>(result, HttpStatus.INTERNAL_SERVER_ERROR);
        }

        return new ResponseEntity<>(result, HttpStatus.OK);
    }

    @GetMapping(value = "/getAllDocuments")
    @Operation(description = "Get list of documents")
    public ResponseEntity<ResultDto<List<DocumentResponseDto>>> getAllDocuments(){
        log.debug("call getAllDocuments");
        ResultDto<List<DocumentResponseDto>> result = new ResultDto<List<DocumentResponseDto>>();

        try{
            List<DocumentResponseDto> responseDto = new ArrayList<DocumentResponseDto>();
            documentService.getAll().forEach( (n) -> {responseDto.add(documentService.response(n));} );
            if(!responseDto.isEmpty()){
                result.setSuccessTrueResponse("N. document " + responseDto.size());
                result.setData(responseDto);
            }else{
                result.setSuccessFalseResponse("Empty list");
                result.setCode(HttpStatus.BAD_REQUEST.value());
            }
        }catch (Exception ex){
            log.error("error getAllDocuments:", ex);

            result.setFailureResponse("Server error", HttpStatus.INTERNAL_SERVER_ERROR.value());
            return new ResponseEntity<>(result, HttpStatus.INTERNAL_SERVER_ERROR);
        }

        return new ResponseEntity<>(result, HttpStatus.OK);
    }


    @PostMapping(value = "/updateDocument")
    @Operation(description = "Update document")
    public ResponseEntity<ResultDto<DocumentResponseDto>> updateDocument(@RequestParam(name = "id") Long id, @RequestBody DocumentRequestDto requestDto){
        log.debug("call updateDocument");
        ResultDto<DocumentResponseDto> result = new ResultDto<DocumentResponseDto>();

        try{
            DocumentResponseDto responseDto = documentService.response(documentService.update(id, requestDto));

            if(responseDto.getId() != -1L){
                result.setSuccessTrueResponse("update success");
                result.setData(responseDto);
            }else{
                result.setSuccessFalseResponse("update not success");
                result.setCode(HttpStatus.BAD_REQUEST.value());
            }
        }catch (Exception ex){
            log.error("error updateDocument:", ex);

            result.setFailureResponse("Server error", HttpStatus.INTERNAL_SERVER_ERROR.value());
            return new ResponseEntity<>(result, HttpStatus.INTERNAL_SERVER_ERROR);
        }

        return new ResponseEntity<>(result, HttpStatus.OK);
    }

    @DeleteMapping(value = "/deleteDocument")
    @Operation(description = "Delete document by id")
    public ResponseEntity<ResultDto<DocumentResponseDto>> deleteDocument(@RequestParam(name = "id") Long id){
        log.debug("call deleteDocument");
        ResultDto<DocumentResponseDto> result = new ResultDto<DocumentResponseDto>();
        try{
            if(documentService.delete(id)){
                result.setSuccessTrueResponse("delete success");
                result.setData(null);
            }else{
                result.setSuccessFalseResponse("delete not success");
                result.setCode(HttpStatus.BAD_REQUEST.value());
            }

        }catch (Exception ex){
            log.error("error deleteDocument:", ex);

            result.setFailureResponse("Server error", HttpStatus.INTERNAL_SERVER_ERROR.value());
            return new ResponseEntity<>(result, HttpStatus.INTERNAL_SERVER_ERROR);
        }

        return new ResponseEntity<>(result, HttpStatus.OK);
    }
}


