package it.svil.demoapi.util;

import it.svil.demoapi.model.Type;

public class EnumUtil {

    public static boolean isValidDocType(String docType){
        for (Type c : Type.values()) {
            if (c.name().equals(docType)) {
                return true;
            }
        }

        return false;
    }
}
