package it.svil.demoapi.security.controller;

import io.swagger.v3.oas.annotations.tags.Tag;
import it.svil.demoapi.controller.DocumentController;
import it.svil.demoapi.dto.DocumentResponseDto;
import it.svil.demoapi.dto.ResultDto;
import it.svil.demoapi.security.model.AuthResponseDto;
import it.svil.demoapi.security.model.LoginRequestDto;
import it.svil.demoapi.security.model.RegisterRequestDto;
import it.svil.demoapi.security.service.AuthService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.InternalAuthenticationServiceException;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/v1/auth")
@RequiredArgsConstructor
@Tag(name = "Auth", description = "Authentication API")
public class AuthController {
  private static final Logger log = LoggerFactory.getLogger(AuthController.class);

  private final AuthService authService;

  @PostMapping
  public ResponseEntity<ResultDto<AuthResponseDto>> login(@RequestBody LoginRequestDto registerRequestDto) {
    ResultDto<AuthResponseDto> result = new ResultDto<AuthResponseDto>();
    try {
      AuthResponseDto authResponseDto = authService.login(registerRequestDto);
      if(authResponseDto!=null && !authResponseDto.getToken().isBlank()) {
        result.setSuccessTrueResponse("User logged");
        result.setData(authResponseDto);
      }
    }
    catch (BadCredentialsException | InternalAuthenticationServiceException b ){
      log.warn("BadCredentialsException");
      result.setFailureResponse("User not valid",HttpStatus.BAD_REQUEST.value());
      result.setCode(HttpStatus.BAD_REQUEST.value());
      return new ResponseEntity<>(result, HttpStatus.BAD_REQUEST);
    }
    catch (Exception e){
      log.error("Error on login user: ",e);
      result.setFailureResponse("Internal Error",HttpStatus.INTERNAL_SERVER_ERROR.value());
      result.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
      return new ResponseEntity<>(result, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    return new ResponseEntity<>(result, HttpStatus.OK);
  }



  @PostMapping("/register")
    public ResponseEntity<ResultDto<AuthResponseDto>> register(@RequestBody RegisterRequestDto registerRequestDto) {
    ResultDto<AuthResponseDto> result = new ResultDto<AuthResponseDto>();
    try {
      AuthResponseDto authResponseDto = authService.register(registerRequestDto);
      if (authResponseDto != null && !authResponseDto.getToken().isBlank()) {
        result.setSuccessTrueResponse("User registered");
        result.setData(authResponseDto);
      }
    } catch (Exception e) {
      log.error("Error on register user: ", e);
      result.setFailureResponse("Internal Error", HttpStatus.INTERNAL_SERVER_ERROR.value());
      result.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
      return new ResponseEntity<>(result, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    return new ResponseEntity<>(result, HttpStatus.OK);
  }
}
