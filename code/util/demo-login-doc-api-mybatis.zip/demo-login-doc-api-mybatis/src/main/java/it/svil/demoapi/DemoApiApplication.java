package it.svil.demoapi;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Info;
import it.svil.demoapi.model.Document;
import it.svil.demoapi.security.model.User;
import org.apache.ibatis.type.MappedTypes;
import org.mybatis.spring.annotation.MapperScan;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
@OpenAPIDefinition(info = @Info(title = "Demo API", version = "0.0.1", description = "API Information"))

public class DemoApiApplication {

	private static final Logger log = LoggerFactory.getLogger(DemoApiApplication.class);

	public static void main(String[] args) {
		log.info("---Start demo application---");
		SpringApplication.run(DemoApiApplication.class, args);

	}

}
