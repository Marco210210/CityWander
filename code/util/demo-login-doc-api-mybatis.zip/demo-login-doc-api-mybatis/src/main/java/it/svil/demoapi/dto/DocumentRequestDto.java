package it.svil.demoapi.dto;

import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

@Data
public class DocumentRequestDto {

    private String name;
    private String documentType;
    @DateTimeFormat(pattern = "dd-MM-yyyy")
    private Date creationDate;
    private String creator;
    private byte[] content;

}
