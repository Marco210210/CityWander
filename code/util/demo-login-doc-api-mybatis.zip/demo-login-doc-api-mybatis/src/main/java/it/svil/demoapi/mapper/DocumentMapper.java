package it.svil.demoapi.mapper;

import it.svil.demoapi.dto.DocumentRequestDto;
import it.svil.demoapi.model.Document;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;

import java.util.List;

@Mapper
public interface DocumentMapper{
    Document findById(@Param("id") Long id);

    List<Document> findAll();

    void update(Document document);

    void insert(Document document);

    void delete(@Param("id") Long id);
}
