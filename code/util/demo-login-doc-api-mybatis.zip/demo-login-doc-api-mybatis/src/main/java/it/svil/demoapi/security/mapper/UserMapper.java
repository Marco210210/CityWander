package it.svil.demoapi.security.mapper;

import it.svil.demoapi.security.model.User;
import org.apache.ibatis.annotations.*;


import java.util.Optional;

@Mapper
public interface UserMapper {
  User findByEmail(String email);

  void insert(User user);
}
