package it.svil.demoapi.configuration;


import it.svil.demoapi.mapper.DocumentMapper;
import it.svil.demoapi.security.mapper.UserMapper;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.mapper.MapperFactoryBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.transaction.PlatformTransactionManager;

import javax.sql.DataSource;

@Configuration
public class MyBatisConfiguration {

    public final String MAPPER_USERS = "mapper/UsersMapper.xml";
    public final String MAPPER_DOCUMENT = "mapper/DocumentMapper.xml";
    public final String TYPE_ALIASES_PACKAGE = "it.svil.demoapi.mapper";
    public final String CONFIG_FILE_NAME = "mybatis-config.xml";

    @Value(value = "${spring.datasource.driverClassName}")
    private String dataSourceDriverClassName;

    @Value(value = "${spring.datasource.url}")
    private String dataSourceUrl;

    @Value(value = "${spring.datasource.username}")
    private String dataSourceUsername;

    @Value(value = "${spring.datasource.password}")
    private String dataSourcePassword;

    @Primary
    @Bean
    public DataSource getDataSource() {
        DriverManagerDataSource dataSource = new DriverManagerDataSource();
        dataSource.setDriverClassName(dataSourceDriverClassName);
        dataSource.setUrl(dataSourceUrl);
        dataSource.setUsername(dataSourceUsername);
        dataSource.setPassword(dataSourcePassword);
        return dataSource;
    }

    @Primary
    @Bean
    public PlatformTransactionManager transactionManager() {
        DataSourceTransactionManager transactionManager = new DataSourceTransactionManager(getDataSource());
        transactionManager.setGlobalRollbackOnParticipationFailure(true);
        return transactionManager;
    }

    //patient

    @Primary
    @Bean
    public SqlSessionFactory sqlSessionFactoryBeanUserMapper() throws Exception {
        SqlSessionFactoryBean sqlSessionFactoryBean = new SqlSessionFactoryBean();
        sqlSessionFactoryBean.setDataSource(getDataSource());
        PathMatchingResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();
        sqlSessionFactoryBean.setMapperLocations(resolver.getResources(MAPPER_USERS));
        sqlSessionFactoryBean.setTypeAliasesPackage(TYPE_ALIASES_PACKAGE);
        sqlSessionFactoryBean.setConfigLocation(new ClassPathResource(CONFIG_FILE_NAME));
        return sqlSessionFactoryBean.getObject();
    }
    @Primary
    @Bean
    public MapperFactoryBean<UserMapper> userMapper() throws Exception {
        MapperFactoryBean<UserMapper> factoryBeanUserMapper = new MapperFactoryBean<>(UserMapper.class);
        factoryBeanUserMapper.setSqlSessionFactory(sqlSessionFactoryBeanUserMapper());
        return factoryBeanUserMapper;
    }

    //practitioner

    @Bean
    public SqlSessionFactory sqlSessionFactoryBeanDocumentMapper() throws Exception {
        SqlSessionFactoryBean sqlSessionFactoryBean = new SqlSessionFactoryBean();
        sqlSessionFactoryBean.setDataSource(getDataSource());
        PathMatchingResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();
        sqlSessionFactoryBean.setMapperLocations(resolver.getResources(MAPPER_DOCUMENT));
        sqlSessionFactoryBean.setTypeAliasesPackage(TYPE_ALIASES_PACKAGE);
        sqlSessionFactoryBean.setConfigLocation(new ClassPathResource(CONFIG_FILE_NAME));
        return sqlSessionFactoryBean.getObject();
    }
    @Primary
    @Bean
    public MapperFactoryBean<DocumentMapper> documentMapper() throws Exception {
        MapperFactoryBean<DocumentMapper> factoryBeanDocumentMapper = new MapperFactoryBean<>(DocumentMapper.class);
        factoryBeanDocumentMapper.setSqlSessionFactory(sqlSessionFactoryBeanDocumentMapper());
        return factoryBeanDocumentMapper;
    }
}
